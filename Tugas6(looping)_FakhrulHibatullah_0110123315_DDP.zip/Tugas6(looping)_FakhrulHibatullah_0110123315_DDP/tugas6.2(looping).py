
total = 0
for i in range(1, 20, 2):
    total += i

print("hasil penjumlahan dari deret 1 + 3 + 5 + 7 + 9 + 11 + 13 + 15 + 17 + 19 adalah", total)
